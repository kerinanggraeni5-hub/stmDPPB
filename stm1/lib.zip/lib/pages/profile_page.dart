import 'package:flutter/material.dart';

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F7FB),
      appBar: AppBar(
        title: const Text('Profil Pengguna'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            /// ================= FOTO PROFIL =================
            const CircleAvatar(
              radius: 55,
              backgroundImage: AssetImage('assets/images/user.png'),
            ),

            const SizedBox(height: 16),

            const Text(
              'Kerin Anggraeni',
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 4),

            const Text(
              'kerin@student.telkomuniversity.ac.id',
              style: TextStyle(color: Colors.grey),
            ),

            const SizedBox(height: 24),

            /// ================= DATA =================
            _item('NIK', '3273xxxxxxxxxxxx'),
            _item('No Telepon', '08xxxxxxxxxx'),
            _item('Jenis Kelamin', 'Perempuan'),
            _item('Alamat', 'Bandung, Jawa Barat'),

            const SizedBox(height: 32),

            /// ================= LOGOUT =================
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                icon: const Icon(Icons.logout),
                label: const Text('Logout'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.red,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                ),
                onPressed: () {
                  Navigator.pushNamedAndRemoveUntil(
                    context,
                    '/login',
                    (route) => false,
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// ================= ITEM =================
  static Widget _item(String title, String value) {
    return Card(
      elevation: 2,
      margin: const EdgeInsets.only(bottom: 12),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: ListTile(
        title: Text(title),
        subtitle: Text(value),
      ),
    );
  }
}
